#ifndef _TIM_H_
#define _TIM_H_

#include "stm32f10x.h"
#include "sys.h"

void TIM_Config(void);

#endif

